#include<iostream>
using namespace std;

int main(){
	int x[5] = {1,2,3,4,56}; // declaration of 1 D array
//	x[0] = 10;
//	x[1] = 20;
//	cout<<x[2];
	
	int n[2][2] = {
	{2, 4},
	{5, 6}
	};
	cout<<n[1][1];
}

