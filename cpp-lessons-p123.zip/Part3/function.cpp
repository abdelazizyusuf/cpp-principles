#include<iostream>
using namespace std;

void test();
// calling function
int main(){
	test();	
}

void test(){
	int x = 10;
	int y = 20;
	int sum = x + y; // 4 + 6 = 10
	cout<<sum; // i
}
