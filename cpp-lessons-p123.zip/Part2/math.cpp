#include<iostream>
#include<cmath>
using namespace std;

int main(){
	// Trignometric functions
	float x = 0.5;
	cout<<sin(x)<<endl;
	cout<<cos(x)<<endl;
	
	// other function
	cout<<sqrt(x)<<endl;
	cout<<pow(3,3);
	

}
