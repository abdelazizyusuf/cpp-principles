#include<iostream>
using namespace std;

int main(){
	// 1 to 10
	// 10 to 1
	int x = 10;
	while (x >= 1){
//		cout<<x<<endl;
		cout<<"C++"<<endl;
		x--;		
	}	
}

