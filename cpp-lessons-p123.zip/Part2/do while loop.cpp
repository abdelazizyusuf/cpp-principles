#include<iostream>
using namespace std;

int main(){
	// 1 to 10
	// 10 to 1
//	int x = 5;
//	do {
//		cout<<"JafriCode";
//	}while(x == 1);
//	
	int n = 0;
	while (n == 5){
		cout<<"JAFRICODE";
	}
		
}

