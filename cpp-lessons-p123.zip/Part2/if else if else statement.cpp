#include<iostream>
using namespace std;

int main(){
	int n = 0;
	if(n > 0) {
		cout<<"Positive number";
	} 
	else if (n < 0) {
		cout<<"Negative Number";
	}
	
	else {
		cout<<"Number is zero";
	}
}
