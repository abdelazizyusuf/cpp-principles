#include<iostream>
using namespace std;

int main(){
	// 1 to 10
	// 10 to 1
//	for(int i = 1; i <= 10; i++){
//		cout<<i<<endl;
//	}
//		for(int i = 10; i >= 1; i--){
//		cout<<i<<endl;
//	}

	for(int i = 1; i <= 10; i++){
		cout<<"C++"<<i<<endl;
	}
}
