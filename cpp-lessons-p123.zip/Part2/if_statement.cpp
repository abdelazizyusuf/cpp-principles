#include<iostream>
using namespace std;

int main(){
	int marks = 60;
	if(marks > 90){ // false
		cout<<"You are pass.";
	}
}
