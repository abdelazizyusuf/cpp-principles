#include<iostream>
using namespace std;

int main(){
	int marks = 55;
	if(marks > 90){ // True
		cout<<"You are pass.";
		cout<<"Grade A+";
		cout<<"JafriCode";
	}
	else {
		cout<<"You are fail..";
	}
}
