#include<iostream>
using namespace std;

int main(){
	string name = "Faisal Zamir";
	cout<<name.at(0)<<endl;
	string first_Name = "Faisal";
	string last_name = "Zamir";
	cout<<first_Name +" "+ last_name<<endl;
	cout<<"Total char = "<<name.length();
}
