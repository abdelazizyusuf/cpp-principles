#include<iostream>
using namespace std;

int main(){
	int x = 9;
	
	switch(x){
		case 9:
		cout<<"X value is 9";
		cout<<"JafriCode";
		break;
		
		case 4:
		cout<<"X value is 4";
		break;
		
		case 3:
		cout<<"X value is 3";
		break;
		
		case 100:
		cout<<"JafriCode";
		break;
		
		default:
			cout<<"Not matching...";
	}

}
