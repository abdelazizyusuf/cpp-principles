#include<iostream>
using namespace std;

int main(){
	int x;  //This is the declaration of variable
	x = 10; // I assigned value to x variable

	cout<<x; // Displaying value of x
	
	/*
	This code is 
	written by 
	Faisal Zamir
	
	*/
	
}
