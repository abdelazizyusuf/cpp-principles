#include<iostream>
using namespace std;

int main(){
	// variable
	// data type variable name;
	int x; // declaration 
	x = 20; // initialization
	int a, b, c;
	a = 10;
	b = 10;
	c = 10;
	a = b = c = 10;
	char gender;
	gender = 'F';
	cout<<a + b + c;
//	int first_name;
	
}
