#include<iostream>
using namespace std;

int main(){
	cout<<"This is the basic structure of C++";
}
