#include<iostream>
using namespace std;

int main(){
	// integer data types
	int x = 123; // 4 byte
	cout<<x;
	signed short y = -32  // 2 byte
	cout<<y;
	unsigned long z = 2323 // 8 byte
	cout<<z;
	bool is_student = true;
	char gender = 'M';
	
}

