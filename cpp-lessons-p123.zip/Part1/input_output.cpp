#include<iostream>
using namespace std;

int main(){
	int x;
	cout<<"Enter a number";
	cin>>x;
	cout<<"Your number is = "<<x<<endl;
	cout<<"Faisal \t Zamir";
	
	
}
